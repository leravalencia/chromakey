> This directory is used to create the initial image sequence
 